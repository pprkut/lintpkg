#!/bin/sh

GDK_USE_XFT=1
export GDK_USE_XFT
